/* ============================================
   AEC Website - Core Application
   Comprehensive interactive features
   ============================================ */

// ===== EDITABLE CONFIG =====
window.AEC_CONFIG = {
  schoolName: "Ambassadors Educational Complex",
  shortName: "AEC",
  tagline: "Faith • Vision • Discipline",
  phones: [
    { display: "+237 677 637 429", whatsapp: "237677637429" },
    { display: "+237 679 688 792", whatsapp: "237679688792" }
  ],
  emails: ["info@ambassadors-edu.cm", "admissions@ambassadors-edu.cm"],
  address: {
    full: "Emana, Yaoundé — Behind the Presidency, after Government Bilingual High School",
    short: "Emana, Yaoundé, Cameroon"
  },
  socials: {
    facebook: "https://facebook.com/",
    instagram: "https://instagram.com/",
    youtube: "https://youtube.com/",
    linkedin: "https://linkedin.com/"
  },
  waGreeting: {
    en: "Hello, I would like more information about Ambassadors Educational Complex.",
    fr: "Bonjour, je souhaite avoir plus d'informations sur Ambassadors Educational Complex."
  }
};

// ============ TOAST NOTIFICATIONS ============
const Toast = {
  container: null,
  ensure() {
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.className = 'toast-container';
      this.container.setAttribute('aria-live', 'polite');
      document.body.appendChild(this.container);
    }
  },
  show(opts) {
    this.ensure();
    const { title = '', message = '', type = 'info', duration = 4000 } = opts;
    const icons = { success: '✓', warning: '⚠', error: '✕', info: 'ℹ' };
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = `
      <div class="toast-icon">${icons[type] || icons.info}</div>
      <div class="toast-body">
        ${title ? `<div class="toast-title">${title}</div>` : ''}
        <div class="toast-msg">${message}</div>
      </div>
      <button class="toast-close" aria-label="Close">×</button>
    `;
    this.container.appendChild(t);
    requestAnimationFrame(() => t.classList.add('show'));
    const close = () => {
      t.classList.remove('show');
      setTimeout(() => t.remove(), 400);
    };
    t.querySelector('.toast-close').addEventListener('click', close);
    if (duration) setTimeout(close, duration);
  },
  success(message, title) { this.show({ title, message, type: 'success' }); },
  error(message, title)   { this.show({ title, message, type: 'error' }); },
  warning(message, title) { this.show({ title, message, type: 'warning' }); },
  info(message, title)    { this.show({ title, message, type: 'info' }); }
};
window.Toast = Toast;

// ============ i18n ENGINE ============
const I18n = {
  current: localStorage.getItem('aec_lang') || 'en',

  apply() {
    const lang = (typeof TRANSLATIONS !== 'undefined' && TRANSLATIONS[this.current]) ? this.current : 'en';
    document.documentElement.lang = lang;

    if (typeof TRANSLATIONS !== 'undefined') {
      document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) el.innerHTML = TRANSLATIONS[lang][key];
      });
      document.querySelectorAll('[data-i18n-ph]').forEach(el => {
        const key = el.getAttribute('data-i18n-ph');
        if (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) el.placeholder = TRANSLATIONS[lang][key];
      });
    }

    document.querySelectorAll('.lang-switch button').forEach(b => {
      b.classList.toggle('active', b.dataset.lang === lang);
    });

    this.refreshWALinks();
  },

  set(lang) {
    if (typeof TRANSLATIONS !== 'undefined' && !TRANSLATIONS[lang]) return;
    this.current = lang;
    localStorage.setItem('aec_lang', lang);
    this.apply();
    if (window.Toast) {
      Toast.info(lang === 'fr' ? 'Langue : Français' : 'Language: English');
    }
  },

  refreshWALinks() {
    const greeting = encodeURIComponent(AEC_CONFIG.waGreeting[this.current] || AEC_CONFIG.waGreeting.en);
    document.querySelectorAll('a[data-wa-num]').forEach(link => {
      const num = link.dataset.waNum;
      link.href = `https://wa.me/${num}?text=${greeting}`;
      link.target = '_blank';
      link.rel = 'noopener';
    });
  }
};
window.I18n = I18n;

// ============ HEADER SCROLL EFFECT ============
function initHeaderScroll() {
  const header = document.querySelector('.header');
  if (!header) return;
  const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 20);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

// ============ MOBILE MENU ============
function initMobileMenu() {
  const btn = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  if (!btn || !nav) return;

  let backdrop = document.querySelector('.nav-backdrop');
  if (!backdrop) {
    backdrop = document.createElement('div');
    backdrop.className = 'nav-backdrop';
    document.body.appendChild(backdrop);
  }

  const open = () => {
    nav.classList.add('open');
    btn.classList.add('open');
    backdrop.classList.add('show');
    btn.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  };
  const close = () => {
    nav.classList.remove('open');
    btn.classList.remove('open');
    backdrop.classList.remove('show');
    btn.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  };

  btn.addEventListener('click', () => {
    nav.classList.contains('open') ? close() : open();
  });
  backdrop.addEventListener('click', close);
  nav.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      if (window.innerWidth <= 1024) close();
    });
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && nav.classList.contains('open')) close();
  });
  window.addEventListener('resize', () => {
    if (window.innerWidth > 1024) close();
  });
}

// ============ REVEAL ON SCROLL ============
function initReveals() {
  if (!('IntersectionObserver' in window)) return;
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));
}

// ============ SCROLL TO TOP ============
function initScrollTop() {
  let btn = document.querySelector('.scroll-top');
  if (!btn) {
    btn = document.createElement('button');
    btn.className = 'scroll-top';
    btn.setAttribute('aria-label', 'Scroll to top');
    btn.innerHTML = '↑';
    document.body.appendChild(btn);
  }
  const onScroll = () => btn.classList.toggle('show', window.scrollY > 400);
  window.addEventListener('scroll', onScroll, { passive: true });
  btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  onScroll();
}

// ============ SMOOTH SCROLL ============
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const href = a.getAttribute('href');
      if (href === '#' || href.length < 2) return;
      const target = document.querySelector(href);
      if (!target) return;
      e.preventDefault();
      const y = target.getBoundingClientRect().top + window.scrollY - 100;
      window.scrollTo({ top: y, behavior: 'smooth' });
      history.pushState(null, '', href);
    });
  });
}

// ============ FORMS ============
function initForms() {
  // Generic demo forms
  document.querySelectorAll('form[data-demo-form]').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      handleDemoSubmit(form);
    });
  });

  // Contact form
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      if (contactForm.website && contactForm.website.value) return; // honeypot
      const submitBtn = contactForm.querySelector('button[type="submit"]');
      const status = document.getElementById('formStatus');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner"></span> ' + (I18n.current === 'fr' ? 'Envoi…' : 'Sending…');
      }
      setTimeout(() => {
        try {
          const subs = JSON.parse(localStorage.getItem('aec_contact_submissions') || '[]');
          subs.push({ when: new Date().toISOString(), data: Object.fromEntries(new FormData(contactForm)) });
          localStorage.setItem('aec_contact_submissions', JSON.stringify(subs));
        } catch (e) {}
        if (status) {
          status.style.color = '#86EFAC';
          status.textContent = '✓ ' + (I18n.current === 'fr'
            ? 'Merci ! Votre message a été reçu. Nous vous répondrons sous un jour ouvrable.'
            : 'Thank you! Your message has been received. We will respond within one working day.');
        }
        Toast.success(
          I18n.current === 'fr' ? 'Nous vous répondrons sous un jour ouvrable.' : 'We will respond within one working day.',
          I18n.current === 'fr' ? 'Message envoyé !' : 'Message sent!'
        );
        contactForm.reset();
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = I18n.current === 'fr' ? 'Envoyer le message' : 'Send Message';
        }
      }, 900);
    });
  }

  // Admission application form
  const admissionForm = document.getElementById('admissionForm');
  if (admissionForm) {
    admissionForm.addEventListener('submit', e => {
      e.preventDefault();
      handleDemoSubmit(admissionForm,
        I18n.current === 'fr'
          ? 'Demande d\'inscription envoyée ! Notre bureau vous contactera dans les 48 heures pour la suite.'
          : 'Application submitted! Our office will contact you within 48 hours with next steps.'
      );
    });
  }

  // Newsletter forms
  document.querySelectorAll('form[data-newsletter]').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const input = form.querySelector('input[type="email"]');
      if (!input || !input.value) return;
      const email = input.value;
      try {
        const subs = JSON.parse(localStorage.getItem('aec_newsletter') || '[]');
        if (!subs.includes(email)) subs.push(email);
        localStorage.setItem('aec_newsletter', JSON.stringify(subs));
      } catch (e) {}
      Toast.success(
        I18n.current === 'fr' ? `${email} a été ajouté à notre liste.` : `${email} added to our newsletter.`,
        I18n.current === 'fr' ? 'Abonnement réussi !' : 'Subscribed!'
      );
      form.reset();
    });
  });

  // Login form (portal)
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', e => {
      e.preventDefault();
      const status = document.getElementById('loginStatus');
      const submitBtn = loginForm.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner"></span> ' + (I18n.current === 'fr' ? 'Connexion…' : 'Signing in…');
      }
      setTimeout(() => {
        if (status) {
          status.style.color = '#0E5C30';
          status.textContent = '✓ ' + (I18n.current === 'fr'
            ? 'Démo : en production, ceci se connecte à votre backend sécurisé.'
            : 'Demo: in production this connects to your secure backend.');
        }
        Toast.info(
          I18n.current === 'fr' ? 'Mode démo : aucune authentification réelle.' : 'Demo mode: no real authentication occurs.',
          I18n.current === 'fr' ? 'Démonstration' : 'Demo'
        );
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = I18n.current === 'fr' ? 'Se connecter' : 'Sign In Securely';
        }
      }, 800);
    });
  }
}

function handleDemoSubmit(form, customMsg) {
  const submitBtn = form.querySelector('button[type="submit"]');
  let orig;
  if (submitBtn) {
    submitBtn.disabled = true;
    orig = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="spinner"></span> ' + (I18n.current === 'fr' ? 'Envoi…' : 'Submitting…');
  }
  setTimeout(() => {
    Toast.success(
      customMsg || (I18n.current === 'fr'
        ? 'Votre demande a été reçue. Nous vous contacterons sous 48 heures.'
        : 'Your request has been received. We will be in touch within 48 hours.'),
      I18n.current === 'fr' ? 'Merci !' : 'Thank you!'
    );
    form.reset();
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.innerHTML = orig;
    }
  }, 900);
}

// ============ FLOATING WHATSAPP ============
function initWhatsAppFloat() {
  if (document.querySelector('.whatsapp-float')) return;
  const a = document.createElement('a');
  a.className = 'whatsapp-float';
  a.dataset.waNum = AEC_CONFIG.phones[0].whatsapp;
  a.title = 'WhatsApp';
  a.target = '_blank';
  a.rel = 'noopener';
  a.setAttribute('aria-label', 'Chat with us on WhatsApp');
  a.innerHTML = `<svg width="30" height="30" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>`;
  document.body.appendChild(a);
}

// ============ EXTERNAL LINK SAFETY ============
function initExternalLinks() {
  const host = location.hostname;
  document.querySelectorAll('a[href^="http"]').forEach(a => {
    try {
      const u = new URL(a.href);
      if (u.hostname && u.hostname !== host) {
        if (!a.target) a.target = '_blank';
        if (!a.rel) a.rel = 'noopener noreferrer';
      }
    } catch (e) {}
  });
}

// ============ PAGE PROGRESS BAR ============
function initPageProgress() {
  if (document.querySelector('.page-progress')) return;
  const bar = document.createElement('div');
  bar.className = 'page-progress';
  document.body.appendChild(bar);
  const update = () => {
    const h = document.documentElement;
    const max = h.scrollHeight - h.clientHeight;
    const scrolled = max > 0 ? (h.scrollTop / max) * 100 : 0;
    bar.style.width = scrolled + '%';
  };
  window.addEventListener('scroll', update, { passive: true });
  update();
}

// ============ SET ACTIVE NAV BASED ON URL ============
function initActiveNav() {
  try {
    const path = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
    document.querySelectorAll('.nav > ul > li > a').forEach(a => {
      const href = (a.getAttribute('href') || '').split('/').pop().toLowerCase().split('#')[0];
      if (href && href === path && !a.classList.contains('cta-pill')) {
        a.classList.add('active');
      }
    });
  } catch (e) {}
}

// ============ INIT ALL ============
document.addEventListener('DOMContentLoaded', () => {
  I18n.apply();
  initHeaderScroll();
  initMobileMenu();
  initReveals();
  initScrollTop();
  initSmoothScroll();
  initForms();
  initWhatsAppFloat();
  initExternalLinks();
  initPageProgress();
  initActiveNav();

  document.querySelectorAll('.lang-switch button').forEach(btn => {
    btn.addEventListener('click', () => I18n.set(btn.dataset.lang));
  });
});
